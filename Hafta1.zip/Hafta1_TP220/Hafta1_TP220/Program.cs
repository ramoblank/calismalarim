﻿namespace Hafta1_TP220
{
    internal class Program
    {
        static void Main(string[] args)
        {

            //Klavyeden Veri Almak

            //string isim = "Mümtaz";
            //Console.WriteLine("Merhaba" + isim);

            //Console.Write("Adınız : ");
            //string isim = Console.ReadLine();

            //Console.Write("Soyadınız : ");
            //string soyad = Console.ReadLine();

            //Console.WriteLine(isim + soyad);

            //Console.Write("İsim : ");
            //string isim = Console.ReadLine();

            //Console.Write("Şehir : ");
            //string sehir = Console.ReadLine();

            //Console.WriteLine(isim + " eğitime " + sehir + "den katılıyor.");
            //Console.WriteLine("Başarılar " + isim);

            //Console.Write("Bir Sayı Giriniz : ");
            //int sayi = int.Parse(Console.ReadLine());

            //Console.WriteLine(sayi);

            //Aşağıdaki programın çalışmasını sağlayan C# konsol kodunu yazın.
            //1. sayı ve 2. sayı kullanıcıdan istenecektir ve en alt satır girilen değerlere göre
            //değiştirilecektir

            Console.Write("1.Sayı : ");
            int sayi1 = int.Parse(Console.ReadLine());

            Console.Write("2.Sayı : ");
            int sayi2 = int.Parse(Console.ReadLine());

            int toplam = sayi1 + sayi2;

            Console.WriteLine(sayi1 + " ve " + sayi2 + " sayılarının toplamı = " + toplam);






            // ve - veya operatörleri

            // && - ||

            //3 farklı değişken içindeki sayılardan, en büyük olanını ekrana yazdıran kodu
            //yazın.
            //2 farklı yöntem kullanarak yapın.

            //int x = 3;

            //int y = 5;

            //int z = 8;

            //1.Yöntem

            //if (x > y && x > z)
            //{
            //    Console.WriteLine("En Büyük X = " + x);
            //}
            //else if (y > x && y > z)
            //{
            //    Console.WriteLine("En Büyük Y = " + y);
            //}
            //else
            //{
            //    Console.WriteLine("En Büyük Z " + z);
            //}

            //2.Yöntem

            //int eb = x;

            //if (y > eb)
            //{
            //    eb = y;
            //}
            //if (z > eb)
            //{
            //    eb = z;
            //}

            //Console.WriteLine("En Büyük = " + eb);

            //int sayi = 41;

            //if (sayi % 2 != 0 && sayi > 50)
            //{
            //    Console.WriteLine("Durum A");
            //}
            //else if (sayi % 2 != 0 && sayi < 50)
            //{
            //    Console.WriteLine("Durum B");
            //}
            //else
            //{
            //    Console.WriteLine("Durum C");
            //}



            //int sayi = 67;

            //int kalan = sayi % 2;
            //Bir değişkendeki sayının tek mi çift mi olduğunu bulan kodu yazın.
            //Sayı tek ise ekrana “Tektir” yazsın, değilse ekrana “Çifttir” yazsın.

            //Sayının 2'ye bölümünden kalanı 0'a eşitse

            //1.Yöntem

            //if (sayi % 2 == 0)
            //{
            //    Console.WriteLine("Çifttir.");
            //}
            // else
            //{
            //    Console.WriteLine("Tektir.");
            //}

            //2.Yöntem

            //if (kalan == 0)
            //{
            //    Console.WriteLine("Çifttir");
            //}
            //else
            //{
            //    Console.WriteLine("Tektir.");
            //}






            //IF - ELSE
            //Bir değişkendeki sayının pozitif mi, negatif mi ya da nötr mü olduğunu ekrana yazdıran kodu yazın.

            //int sayi = -15;

            //if (sayi > 0)
            //{
            //    Console.WriteLine("Pozitif");
            //}
            //else if (sayi < 0)
            //{
            //    Console.WriteLine("Negatif");
            //}
            //else if (sayi == 0)
            //{
            //    Console.WriteLine("Nötr");
            //}





            //int sayi = 5;

            //if (sayi > 0)
            //{
            //    Console.WriteLine("Sayı 0'dan büyüktür");
            //}

            //    Console.WriteLine();

            //int yas = 8;

            //if (yas >= 25)
            //{
            //    Console.WriteLine("Tır, Kamyon ve Araba Ehliyeti Alabilir");
            //}
            //else if (yas >= 20)
            //{
            //    Console.WriteLine("Kamyon ve Araba Ehliyeti Alabilir.");
            //}
            //else if (yas >= 18)
            //{
            //    Console.WriteLine("Araba Ehliyeti alabilir");
            //}

            //== 0
            // > 0
            // < 0


            //int yas = 15;

            //if (yas >= 18)
            //{
            //    Console.WriteLine("Araba Ehliyeti Alabilir");
            //}
            //else
            //{
            //    Console.WriteLine("Yaş 18'den büyük değil.Ehliyet Alamaz");
            //}

            //Console.WriteLine("Her Koşulda Çalışır");



            // T ☻ dosya 

            //"yil" adında bir değişken oluşturun ve değerine bulunduğumuz yılı atayın,            
            //"dogumYili" adında bir değişken oluşturun, değerine doğum yılınızı atayın.
            //"yas" adında bir değişkende bu verilerle yaşınızı hesaplatın.
            //"yas" değişkenini ekrana yazdırın.

            //int yil = 2025;
            //int dogumYili = 1989;

            //int yas = yil - dogumYili;

            //Console.WriteLine(yas);

            //***************************************

            // double sayi1 = 200;
            //double sayi2 = 87;

            //double sonuc = (sayi1 * 2) / sayi2;

            //Console.WriteLine(sonuc);


            //*********************************
            //string mesaj = "Merhaba";
            //Console.WriteLine(mesaj);

            //Console.WriteLine("Hello World");

            //Console.WriteLine();
            //Console.WriteLine("Siliconmade Academy");
            //Console.WriteLine("www.siliconmadeacademy.com");

            //Console.WriteLine();
            //Console.WriteLine("Merhaba Dünya");
            //Console.WriteLine("Sana da Merhaba");












        }



    }
}
