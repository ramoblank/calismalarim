﻿namespace ButikSinemaUygulamasi_TP220
{
    internal class Sinema
    {
        public string Film;
        public int Kapasite;
        public int TamBiletFiyati;
        public int YarimBiletFiyati;
        public int ToplamTamBiletAdedi;
        public int ToplamYarimBiletAdedi;
        public int Ciro;

        public Sinema()
        {

        }

        public Sinema(string film, int kapasite, int tam, int yarim)
        {
            Film = film;
            Kapasite = kapasite;
            TamBiletFiyati = tam;
            YarimBiletFiyati = yarim;
        }

        public void BiletSatisi(int tamBiletAdeti, int yarimBiletAdeti)
        {
            this.ToplamTamBiletAdedi += tamBiletAdeti;
            this.ToplamYarimBiletAdedi += yarimBiletAdeti;
        }

        public void BiletIadesi(int tamBiletAdeti, int yarimBiletAdeti)
        {
            this.ToplamTamBiletAdedi -= tamBiletAdeti;
            this.ToplamYarimBiletAdedi -= yarimBiletAdeti;
        }

    }


}
