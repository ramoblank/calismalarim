﻿namespace ButikSinemaUygulamasi_TP220
{
    internal class Program
    {
        static Sinema snm = new Sinema();

        static void Main(string[] args)
        {
            Uygulama();


        }

        static void Uygulama()
        {
            Kurulum();
            Menu();

            while (true)
            {
                string secim = SecimAl();

                switch (secim)
                {
                    case "1":
                    case "S":
                        BiletSat();
                        break;
                    case "2":
                    case "R":
                        BiletIade();
                        break;
                    case "3":
                    case "D":
                        DurumBilgisi();
                        break;
                    case "4":
                    case "X":
                        Environment.Exit(0);
                        break;
                }
            }
        }

        static void Kurulum()
        {
            Console.WriteLine("-------Butik Sinema Salonu-------");
            Console.WriteLine();
            Console.Write("Film : ");
            string film = Console.ReadLine();

            Console.Write("Kapasite : ");
            int kapasite = Convert.ToInt32(Console.ReadLine());

            Console.Write("Tam Bilet Fiyati : ");
            int tam = Convert.ToInt32(Console.ReadLine());

            Console.Write("Yarım Bilet Fiyati : ");
            int yarim = Convert.ToInt32(Console.ReadLine());

            snm = new Sinema(film, kapasite, tam, yarim);
        }

        static void Menu()
        {
            Console.WriteLine("1- Bilet Sat (S)");
            Console.WriteLine("2- Bilet İade (R) ");
            Console.WriteLine("3- Durum Bilgisi (D)");
            Console.WriteLine("4- Çıkış (X)");


        }

        static string SecimAl()
        {
            string karakterler = "1234SDRX";
            int sayac = 0;

            while (true)
            {
                sayac++;
                Console.Write("Seçiminiz: ");
                string giris = Console.ReadLine().ToUpper();

                int index = karakterler.IndexOf(giris);

                if (index >= 0)
                {
                    return giris;
                }
                else
                {
                    if (sayac == 10)
                    {
                        Console.WriteLine("Üzgünüm sizi anlamıyorum. Program sonlandırılıyor");
                        Environment.Exit(0);
                    }

                    Console.WriteLine("Hatalı Giriş Yapıldı");
                }
                Console.WriteLine();
            }
        }

        static void BiletSat()
        {
            Console.WriteLine("Bilet Sat");

            Console.Write("Tam Bilet Adedi: ");
            int tam = Convert.ToInt32(Console.ReadLine());

            Console.Write("Yarım Bilet Adedi: ");
            int yarim = Convert.ToInt32(Console.ReadLine());

            snm.BiletSatisi(tam, yarim);

        }

        static void BiletIade()
        {
            Console.WriteLine("Bilet İade");

            Console.Write("Tam Bilet Adedi: ");
            int tam = Convert.ToInt32(Console.ReadLine());

            Console.Write("Yarım Bilet Adedi: ");
            int yarim = Convert.ToInt32(Console.ReadLine());

            snm.BiletIadesi(tam, yarim);


        }

        static void DurumBilgisi()
        {
            Console.WriteLine("Durum Bilgisi");
            Console.WriteLine();
            Console.WriteLine("Film : " + snm.Film);
        }


    }
}
