﻿namespace Hafta_2_TP220
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Kullanıcıdan bir not alan kodu yazın. Bu not;
            //0 - 49 arasındaysa “Başarısız”,
            //50 - 64 arasındaysa “Orta”,
            //65 - 84 arasındaysa “İyi”,
            //85 - 100 arasındaysa “Çok iyi” yazan programın kodunu yazın.
            //Not bu aralıkta değilse program "Hatalı giriş yapıldı" mesajını versin.

            //Klavyenizde && tuşu çalışmıyor,
            //sadece || tuşu çalışıyor olsaydı bu soruyu nasıl çözmek gerekirdi?

            //1.Yöntem

            //Console.Write("Bir Not Giriniz : ");
            //int not = int.Parse(Console.ReadLine());

            //if (not >= 0 && not <= 49)
            //{
            //    Console.WriteLine("Başarısız");
            //}
            //else if (not >= 50 && not <= 64)
            //{
            //    Console.WriteLine("Orta");
            //}
            //else if (not >= 65 && not <= 84)
            //{
            //    Console.WriteLine("İyi");
            //}
            //else if (not >= 85 && not <= 100)
            //{
            //    Console.WriteLine("Çok İyi");
            //}
            //else
            //{
            //    Console.WriteLine("Hatalı Giriş Yapıldı");
            //}

            //2.Yöntem

            //Console.Write("Bir Not Giriniz : ");
            //int not = int.Parse(Console.ReadLine());

            //if (not > 100 || not < 0)
            //{
            //    Console.WriteLine("Hatalı Giriş Yapıldı");
            //}
            //else
            //{
            //    if (not < 50)
            //    {
            //        Console.WriteLine("Başarısız");
            //    }
            //    else if (not < 65)
            //    {
            //        Console.WriteLine("Orta");
            //    }
            //    else if (not < 85)
            //    {
            //        Console.WriteLine("iyi");
            //    }
            //    else if (not <= 100)
            //    {
            //        Console.WriteLine("Çok İyi");
            //    }
            //}

            // WHİLE DÖNGÜSÜ

            //int adet = 5;

            //while (adet > 0)
            //{

            //    Console.WriteLine("Merhaba Dünya");
            //    adet = adet - 1;
            //}

            //10’dan 1’e kadar olan sayıları alt alt’a ekrana yazdıran kodu yazın.

            //int sayi = 10;

            //while (sayi >= 1)
            //{
            //    Console.WriteLine(sayi);
            //    sayi = sayi - 1;
            //}




            //10’dan 1’e kadar olan sayıları yan yana’a ekrana yazdıran kodu yazın.
            //ve aralarına boşluk koyarak ekrana yazdıran kodu ekleyin.

            //int sayi = 10;

            //while (sayi >= 1)
            //{
            //    Console.Write(sayi + " ");
            //    sayi = sayi - 1;
            //}

            //0 ile 100 arasındaki sayıları while döngüsü kullanarak toplayan ve bu değeri
            //ekrana yazdıran kodu yazın.

            //int sayi = 0;
            //int toplam = 0;

            //while (sayi < 100)
            //{
            //    sayi = sayi + 1;
            //    toplam = toplam + sayi;
            //}
            //Console.WriteLine(toplam);

            //0’ile 100 arasındaki tek sayıları toplayarak sonucu ekranda gösteren
            //kodu while döngüsü kullanarak yazın
            //(2 farklı yöntem kullanarak yapınız)

            //int sayi = 0;
            //int toplam = 0;

            //while (sayi < 100)
            //{
            //    sayi = sayi + 1;

            //    if (sayi % 2 != 0)
            //    {
            //        toplam = toplam + sayi;
            //    }

            //}
            //Console.WriteLine(toplam);

            //int sayi = 1;
            //int toplam = 0;

            //while (sayi < 100)
            //{
            //    toplam = toplam + sayi;
            //    sayi = sayi + 2;

            //}
            //Console.WriteLine(toplam);

            //kullanıcının girdiği sayı 0 (sıfır) sayısı olana kadar tekrar tekrar
            //kullanıcıdan sayı girişi alan programın kodunu while döngüsü kullanarak
            //yazın.

            Console.Write("Sayı Giriniz : ");
            int sayi = int.Parse(Console.ReadLine());

            while (sayi != 0)
            {
                Console.WriteLine("Tekrar Bir Sayı Giriniz : ");
                sayi = int.Parse(Console.ReadLine());
            }


            //Hafta 1 Görev Çözümleri

            //Soru 1

            //Console.Write("Fiyatı Giriniz : ");
            //double fiyat = int.Parse(Console.ReadLine());

            //Console.Write("Kar Oranı Giriniz : ");
            //double kar = int.Parse(Console.ReadLine());

            //double sonuc = (fiyat * kar / 100) + fiyat;
            //Console.WriteLine("Satış Fiyatı : " + sonuc);

            //Soru2

            //Console.Write("Kısa Kenar : ");
            //int kısaKenar = int.Parse(Console.ReadLine());

            //Console.Write("Uzun Kenar : ");
            //int uzunKenar = int.Parse(Console.ReadLine());

            //int alan = kısaKenar * uzunKenar;

            //int cevre = (kısaKenar + uzunKenar) * 2;

            //Console.WriteLine("Alan : " + alan);
            //Console.WriteLine("Çevre : " + cevre);

            //Soru3

            //Console.Write("Birim Fiyatı : ");
            //int birimFiyat = int.Parse(Console.ReadLine());

            //Console.Write("Adet : ");
            //int adet = int.Parse(Console.ReadLine());

            //int toplamTutar = birimFiyat * adet;

            //Console.WriteLine("Toplam Tutar : " + toplamTutar);

            //Soru4

            //Console.Write("Sayı Giriniz : ");
            //int girilenSayı = int.Parse(Console.ReadLine());

            //int kare = girilenSayı * girilenSayı;

            //Console.WriteLine("Karesi : " + kare);

            //Soru5

            //Console.Write("X : ");
            //int x = int.Parse(Console.ReadLine());

            //Console.Write("Y : ");
            //int y = int.Parse(Console.ReadLine());

            //int kareFark = (x * x) - (y * y);
            //Console.WriteLine("X ve Y değerlerinin kareleri farkı: " + kareFark);

            //Soru6

            //Console.Write("a = ");
            //int a = int.Parse(Console.ReadLine());

            //Console.Write("b = ");
            //int b = int.Parse(Console.ReadLine());

            //Console.Write("c = ");
            //int c = int.Parse(Console.ReadLine());

            //int sonuc = (2 * b) - (4 * a * c);
            //Console.WriteLine("2b - 4ac = " + sonuc);

            //Soru7

            //Console.Write("Doğum Yılı: ");
            //int yil = int.Parse(Console.ReadLine());

            //int yas = DateTime.Now.Year - yil;

            //if (yas > 17) // yas >= 18
            //{
            //    Console.WriteLine("Ehliyet Alabilir");
            //}
            //else if (yas <= 17)
            //{
            //    Console.WriteLine("Ehliyet Alamaz");
            //}



            //Kullanıcıdan istenen vize ve final notu ile,
            //öğrencinin geçip geçmediğini hesaplayan programın kodunu yazın.

            //Vize: _
            //Final: _

            //Öğrencinin geçme notu hesaplanır.
            //Bunun için vizenin % 40’ı, finalin % 60’ı toplanır. 

            //Not: X

            //Öğrencinin geçip geçmediğini ekrana yazdırın.
            //Geçme notu en az 50 ve final notu en az 60 olmak zorundadır.

            //Console.Write("Vize notu giriniz : ");
            //double vize = double.Parse(Console.ReadLine());

            //Console.Write("Final notu giriniz : ");
            //double final = double.Parse(Console.ReadLine());

            //double not = (vize * 0.4) + (final * 0.6);

            //Console.WriteLine();
            //Console.WriteLine("Not : " + not);
            //Console.WriteLine();

            //if (not >= 50 && final >= 60)
            //{
            //    Console.WriteLine("Geçti");
            //}
            //else
            //{
            //    Console.WriteLine("Kaldı");
            //}
        }
    }
}
